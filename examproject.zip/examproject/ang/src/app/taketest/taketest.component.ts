import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
@Component({
  selector: 'app-taketest',
  templateUrl: './taketest.component.html',
  styleUrls: ['./taketest.component.css']
})
export class TaketestComponent implements OnInit {
ans;

  constructor(private rt:Router) { }
sub(){
  
  var technology=this.ans;
  this.rt.navigate(['test/'+technology])

}
  ngOnInit() {
  }

}
