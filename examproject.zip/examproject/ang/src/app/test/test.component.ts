import { Component, OnInit, asNativeElements } from '@angular/core';
import { ExamService } from '../services/exam.service'
import { ActivatedRoute, Router } from '@angular/router'
import { Observable } from 'rxjs'
import { marks } from 'src/models/marks';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  ques: any[]
  count: number;
  marks: marks
  len;
  timeLeft: number = 60;
  min: number = 2;
  interval;

  ans
  n = this.acr.snapshot.params['technology']
  constructor(private ms: ExamService, private rt: Router, private acr: ActivatedRoute) {
  this.marks = new marks
    this.startTimer();
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
        alert(['You cannot go back'])
    };
  }

  startTimer() {
    this.interval = setInterval(() => {
      if (this.timeLeft > 0) {
        this.timeLeft--;
      }
      else {
        this.min = this.min - 1;
        if (this.min < 0) {
          this.submit();
          clearInterval(this.interval)
        }
        else {
          this.timeLeft = 60;
        }
      }
    }, 1000)
  }

  ngOnInit() {
    var i = this.acr.snapshot.params['technology']
    this.ms.viewqyes(i).subscribe((data) => {
      this.len = data.length
      this.ques = data[0]
    }
    )


  }
  sub(id, correct, question) {

    var i = id + 1;

    this.ms.viewques(this.n, i).subscribe((data) => {
      if (data.length > 0) {
        this.ques = data[0]

      }
      else {

        this.rt.navigate(['marks'])
      }

      if (this.ans === correct) {
        this.marks.question = question;
        this.marks.response = this.ans;
        this.marks.correct = correct;
        this.marks.marks = 1;
        this.marks.status = 'correct'

        this.ms.postmarks(this.marks).subscribe((data) => {
          console.log(data)

        })
        this.ans = "";
      }
      else {
        this.marks.question = question;
        this.marks.response = this.ans;
        this.marks.correct = correct;
        this.marks.marks = 0;
        this.marks.status = 'wrong'
        this.ms.postmarks(this.marks).subscribe((data) => { })
        this.ans = "";
      }

    }

    )
  }
  submit() {
    this.rt.navigate(['marks'])
  }

}





