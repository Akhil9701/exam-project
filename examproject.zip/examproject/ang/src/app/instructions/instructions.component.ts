import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ExamService} from '../services/exam.service'
@Component({
  selector: 'app-instructions',
  templateUrl: './instructions.component.html',
  styleUrls: ['./instructions.component.css']
})
export class InstructionsComponent implements OnInit {

  constructor(private rt:Router,private ms:ExamService) { }
next(){
  this.ms.delmarks().subscribe((data)=>{
    

 })
 
  this.rt.navigate(['taketest'])
}
  ngOnInit() {
  }

}
