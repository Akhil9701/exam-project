import { Component } from '@angular/core';
import {Observable,of} from 'rxjs'
import { Router } from '@angular/router';
import { fadeAnimation } from './animations';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  
})
export class AppComponent {
  title = 'examapi';
  aisValue:Observable<string>
  constructor(private rt:Router) {
    
  }
  private ChekLocalStore():Observable<any>{
    return of(localStorage.getItem("adminid"));
    }
    adminLogoutClick(){
      localStorage.removeItem("adminid")
      this.rt.navigate(['home'])
    }
    ngDoCheck() {
     
      this.ChekLocalStore().subscribe((data) => { this.aisValue = data })
    }
}
