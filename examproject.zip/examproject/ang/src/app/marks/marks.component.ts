import { Component, OnInit } from '@angular/core';
import {ExamService} from '../services/exam.service'
import { Router } from '@angular/router';
@Component({
  selector: 'app-marks',
  templateUrl: './marks.component.html',
  styleUrls: ['./marks.component.css']
})
export class MarksComponent implements OnInit {
ques:any;
qyes:any[];
  constructor(private ms:ExamService,private rt:Router) {
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
        history.go(1);
        alert(['You cannot go back'])
    };
   }
  sub(){
    this.rt.navigate(['taketest'])
  }
  ngOnInit() {
    this.ms.getmarks().subscribe((data)=>{
    
      this.ques=data
   })
   this.ms.getscore().subscribe((data)=>{
     this.qyes=data[0]
   })

  }

}
