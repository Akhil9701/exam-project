export class marks{
    question:string;
    response:string;
    correct:string;
    marks:number;
    status:string;
}