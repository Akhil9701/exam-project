export class question {
    qid: number;
    question: string;
    technology: string;
    A: string;
    B: string;
    C: string;
    D: string;
    correct: string;
}