var fs = require('fs')
var path = require('path')
var bodyparser = require('body-parser')
var express = require('express')
var promise = require('bluebird')

var sheshi = express();
sheshi.use(bodyparser.urlencoded({ extended: true }));
sheshi.use(bodyparser.json())

sheshi.all("*", function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Cache-Control, Pragma,Origin,Authorization, Content-Type, X-Requested-With");
    res.header("Access-Control-Allow-Methods", "*");
    return next();
});

var options = { promiseLib: promise }

var pgp = require('pg-promise')(options)

var cs = 'postgres://postgres:root@localhost:5432/examtask'

var db = pgp(cs)

sheshi.set('port', process.env.PORT || 4600)

sheshi.get('/', (req, res) => {
    res.send('database connected')
})

sheshi.get('/ad/:id/:pwd', (req, res, next) => {
    var id = req.params.id;
    var pwd = req.params.pwd;
    db.any('select * from admin where adminid=$1 and password=$2', [id, pwd]).then(
        (data) => {
            res.send(data)
        })
})


sheshi.get('/questions', (req, res, next) => {

    db.any('select * from questions ').then(
        (data) => {
            res.send(data)
        }
    )
})

sheshi.get('/questi/:technology', (req, res, next) => {
    var tech = req.params.technology;
    db.any('select * from questions where technology=$1', tech).then(
        (data) => {
            res.send(data)
        }
    )
})


sheshi.get('/quest/:tech/:id', (req, res, next) => {
    var teh = req.params.tech;
    var id = req.params.id;
    console.log(teh, id)
    db.any('select * from questions where technology=$1 and qid=$2', [teh, id]).then(
        (data) => {
            res.send(data)
        }
    )
})

sheshi.post('/questions', (req, res, next) => {
    var i = req.body.qid;
    var q = req.body.question;
    var t = req.body.technology;
    var a = req.body.A;
    var b = req.body.B;
    var c = req.body.C;
    var d = req.body.D;
    var cr = req.body.correct;


    db.any('insert into questions values($1,$2,$3,$4,$5,$6,$7,$8)', [i, q, t, a, b, c, d, cr]).then(
        (data) => {
            res.send("msg:inserted")
        }
    )
})

sheshi.get('/marks', (req, res, next) => {
    db.any('select * from marks').then(
        (data) => {
            res.send(data)
        })
})

sheshi.post('/marks1', (req, res, next) => {
    console.log(req.body)
    var q = req.body.question
    var r = req.body.response
    var c = req.body.correct
    var m = req.body.marks
    var s = req.body.status

    db.any('insert into marks values($1,$2,$3,$4,$5)', [q, r, c, m, s]).then(
        (data) => {
            res.send("msg:inserted")
        }
    )
})

sheshi.delete('/marksdel', (req, res, next) => {
    db.any('delete from marks').then(
        (data) => {
            res.send("msg:deleted")
        }
    )
})
sheshi.get('/total', (req, res, next) => {
    db.any('select sum(marks) from marks').then(
        (data) => {
            res.send(data)
        }
    )
})
sheshi.post('/questions', (req, res, next) => {
    console.log(req.body)
    var i = req.body.qid;
    var q = req.body.question;
    var t = req.body.technology;
    var a = req.body.a;
    var b = req.body.b;
    var c = req.body.c;
    var d = req.body.d;
    var cr = req.body.correct;


    db.any('insert into questions values($1,$2,$3,$4,$5,$6,$7,$8)', [i, q, t, a, b, c, d, cr]).then(
        (data) => {
            res.send("msg:inserted")
        }
    )
})

sheshi.listen(sheshi.get('port'), (err) => {
    if (err)
        console.log('server not strated ...')
    else
        console.log('server Started at  : http://localhost:4600')
})






